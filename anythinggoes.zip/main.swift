//Hamad Mohammed Aljenibi / 12/CAI / 2013150794 / 784-2007-8096410-0

// A. Create a collection of type [Any] containing doubles, integers, strings, and booleans.
let anythingGoes: [Any] = [40, 3.64, "Hamad", true, 7, 4.71, "Rashed", false]

// Print the entire collection.
print("The collection contains: \(anythingGoes)")

// B. Loop through the collection and print messages based on the type of each element.
for item in anythingGoes {
    // Check if the item is an Integer.
    if let intValue = item as? Int {
        print("The integer has a value of \(intValue)")
    }
    // Check if the item is a Double.
    else if let doubleValue = item as? Double {
        print("The double has a value of \(doubleValue)")
    }
    // Check if the item is a String.
    else if let stringValue = item as? String {
        print("The string has a value of \(stringValue)")
    }
    // Check if the item is a Boolean.
    else if let boolValue = item as? Bool {
        print("The boolean has a value of \(boolValue)")
    }
}
