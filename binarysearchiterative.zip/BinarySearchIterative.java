/*
Name: Hamad Mohammed Aljenibi
School ID: 2013150794
EID: 784200780964100
Class: 12/CAI
Date:
*/
// Iterative Binary Search Implementation
public class BinarySearchIterative {
    public static int binarySearchIterative(int[] array, int target) {
        int left = 0;
        int right = array.length - 1;
        
        while (left <= right) {
            // Find the middle index
            int mid = left + (right - left) / 2;
            
            // Check if the target is at mid
            if (array[mid] == target) {
                return mid;
            }
            
            // Narrow down the search range
            if (array[mid] > target) {
                right = mid - 1; // Search left half
            } else {
                left = mid + 1; // Search right half
            }
        }
        
        return -1; // Target not found
    }
    
    // Recursive Binary Search Implementation
    public static int binarySearchRecursive(int[] array, int target, int left, int right) {
        if (left > right) {
            return -1; // Base case: Target not found
        }
        
        int mid = left + (right - left) / 2;
        
        // Check if the target is at mid
        if (array[mid] == target) {
            return mid;
        }
        
        // Recursive case: Search in the left or right half
        if (array[mid] > target) {
            return binarySearchRecursive(array, target, left, mid - 1);
        } else {
            return binarySearchRecursive(array, target, mid + 1, right);
        }
    }
    
    public static void main(String[] args) {
        int[] array = {1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21};
        int target = 7;
        
        // Testing Iterative Binary Search
        int iterativeResult = binarySearchIterative(array, target);
        System.out.println("Number " + target + " found at index: " + iterativeResult);
        
        // Testing Recursive Binary Search
        int recursiveResult = binarySearchRecursive(array, target, 0, array.length - 1);
        System.out.println("Number " + target + " found at index: " + recursiveResult);
    }
}
