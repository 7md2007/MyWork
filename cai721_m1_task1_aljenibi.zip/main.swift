/*
Hamad Mohammed Aljenibi
2013150794
784200780964100
12/CAI
*/
// Part A: Iterate over numbers 1 to 10
for number in 1...10 {
    print(number)
}

print() // Blank line for better readability

// Part B: Iterate through each character of the string with its index
let quote = "ATS is the best"

for (index, character) in quote.enumerated() {
    print("Index: \(index), Character: \(character)")
}
