//Hamad Mohammed Aljenibi / 12/CAI / 2013150794 / 784-2007-8096410-0

// A. Define a function 'checkPassword' that takes an optional String as a parameter.
func checkPassword(_ password: String?) {
    // B. Use guard statement with optional binding to ensure the password is not nil and has at least 8 characters.
    guard let password = password, password.count >= 8 else {
        print("Invalid password. It must be at least 8 characters long.")
        return
    }
    // If the guard conditions are met, the function continues.
    print("Password is valid.")
}

// C. Create two optional string variables 'password' and 'password2' with initial values.
var password: String? = "pass"
var password2: String? = "correctpassword"

// D. Use the checkPassword function to validate both passwords.
checkPassword(password)   // Expected output: "Invalid password. It must be at least 8 characters long."
checkPassword(password2)  // Expected output: "Password is valid."
