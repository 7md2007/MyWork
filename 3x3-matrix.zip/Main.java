//Hamad Mohammed Aljenibi
//2013150794
//784200780964100
//12CAI
public class Main {
    public static void main(String[] args) {
        // Step 1: Define a 3x3 matrix
        int[][] matrix = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };

        // Step 2:modify the element at the second row and third column (initial value 6) to 10
        matrix[1][2] = 10;

        // Print the modified matrix
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }
}

