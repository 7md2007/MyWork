/*
Hamad Mohammed Aljenibi
2013150794
784200780964100
12/CAI
*/
import Foundation

// Subtask 2: Simulate rolling a six-sided dice until a 1 is rolled
var diceValue: Int

repeat {
    // Roll the dice
    diceValue = Int.random(in: 1...6)
    
    // Print the dice value
    print("Dice rolled: \(diceValue)")
} while diceValue != 1
