//Hamad Mohammed Aljenibi / 12/CAI / 2013150794 / 784-2007-8096410-0

// A. Declare a global variable with an initial value.
var globalVariable: String = "Original Value"

// B. Define a function that shadows the global variable.
func shadowFunction() {
    // This constant 'globalVariable' shadows the global variable within the scope of this function.
    // Inside this function, any reference to 'globalVariable' refers to this constant instead of the global one.
    let globalVariable = "Temporary Value"
    print(globalVariable) // Prints "Temporary Value"
}

// C. Call the function and then print the global variable.
shadowFunction()       // Outputs: Temporary Value
print(globalVariable)  // Outputs: Original Value

/*
D. Explanation:
Variable shadowing occurs when a local variable (or constant) within a certain scope has the same name as a variable declared in an outer scope. 
In this code, the constant 'globalVariable' declared inside 'shadowFunction' shadows the global variable 'globalVariable'. 
This means that within 'shadowFunction', references to 'globalVariable' refer to the local constant ("Temporary Value"), 
while outside the function, 'globalVariable' still refers to the global variable ("Original Value").
*/
