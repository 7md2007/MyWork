/*
Hamad Mohammed Aljenibi
2013150794
784200780964100
12/CAI
*/

for number in 1...20 {
    if number % 3 == 0 {
        print("Skipping \(number)")
        continue
    }
    
    if number % 7 == 0 {
        print("Breaking the loop at number \(number)")
        break
    }
    
    print("Number: \(number)")
}
