/*
Name: Hamad Mohammed Aljenibi
School ID: 2013150794
EID: 784200780964100
Class: 12/CAI
Date:
*/
public class Main {
	public static void main(String[] args) {
		Animal myObject;
		
		myObject = new Animal();
		myObject.makeSound();
		
		// Dog Object
		myObject = new Dog();
		myObject.makeSound();
		
		//Cat Object
		myObject = new Cat();
		myObject.makeSound();
	}
}
