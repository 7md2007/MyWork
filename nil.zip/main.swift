//Hamad Mohammed Aljenibi - 784-2007-8096410-0 - 201315094 - 12/CAI

var username: String? = nil  // The username may or may not have a value

// Safe unwrapping using optional binding
if let name = username {
    print("User's name is \(name)")
} else {
    print("No username provided")
}
