/*
Name: Hamad Mohammed Aljenibi
School ID: 2013150794
EID: 784200780964100
Class: 12/CAI
Date:
*/
public class RecursiveSum {
    public static void main(String[] args) {
        int[] numbers = {5, 10, 15, 20};
        int result = sum(numbers, 0);
        System.out.println("Total sum: " + result);
    }

    // Recursive method using an index instead of creating new arrays
    public static int sum(int[] array, int index) {
        // Base case: If index reaches the end, return 0
        if (index == array.length) {
            System.out.println("Current array length: 0, Current sum: 0");
            return 0;
        }

        // Print current array length and sum
        System.out.println("Current array length: " + (array.length - index) + 
                           ", Current sum: " + array[index]);

        // Recursive case: Add the current element to the sum of the rest
        return array[index] + sum(array, index + 1);
    }
}
