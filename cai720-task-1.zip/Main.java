/*
Name: Hamad Mohammed Aljenibi
School ID: 2013150794
EID: 784200780964100
Class: 12/CAI
Date: 16/1/2025
*/
import java.util.ArrayList;

/**
 * Polymorphism is a fundamental concept in object-oriented programming that allows a single method 
 * or action to perform differently based on the object it is called on. For example, the method 
 * displayDetails() has the same name and signature but behaves uniquely depending on the specific 
 * type of Vehicle (such as Car, Truck, or Bike) it is executed on.
 */
 
class Vehicle {
    // Attributes
    protected String brand;
    protected double pricePerDay;
    protected int rentalDays;

    // Constructor
    public Vehicle(String brand, double pricePerDay, int rentalDays) {
        this.brand = brand;
        this.pricePerDay = pricePerDay;
        this.rentalDays = rentalDays;
    }

    // Method to calculate rental cost
    public double calculateRentalCost() {
        return pricePerDay * rentalDays;
    }

    // Method to display vehicle details
    public void displayDetails() {
        System.out.println(this.getClass().getSimpleName() + " - Brand: " + brand + 
                           ", Price Per Day: " + pricePerDay + 
                           ", Rental Days: " + rentalDays);
    }
}

// Subclass Car
class Car extends Vehicle {
    private int numDoors;

    public Car(String brand, double pricePerDay, int rentalDays, int numDoors) {
        super(brand, pricePerDay, rentalDays);
        this.numDoors = numDoors;
    }

    @Override
    public void displayDetails() {
        System.out.println("Car - Brand: " + brand + 
                           ", Price Per Day: " + pricePerDay + 
                           ", Rental Days: " + rentalDays + 
                           ", Number of Doors: " + numDoors);
    }
}

// Subclass Truck
class Truck extends Vehicle {
    private double cargoCapacity;

    public Truck(String brand, double pricePerDay, int rentalDays, double cargoCapacity) {
        super(brand, pricePerDay, rentalDays);
        this.cargoCapacity = cargoCapacity;
    }

    @Override
    public void displayDetails() {
        System.out.println("Truck - Brand: " + brand + 
                           ", Price Per Day: " + pricePerDay + 
                           ", Rental Days: " + rentalDays + 
                           ", Cargo Capacity: " + cargoCapacity);
    }
}

// Subclass Bike
class Bike extends Vehicle {
    private int engineCapacity;

    public Bike(String brand, double pricePerDay, int rentalDays, int engineCapacity) {
        super(brand, pricePerDay, rentalDays);
        this.engineCapacity = engineCapacity;
    }

    @Override
    public void displayDetails() {
        System.out.println("Bike - Brand: " + brand + 
                           ", Price Per Day: " + pricePerDay + 
                           ", Rental Days: " + rentalDays + 
                           ", Engine Capacity: " + engineCapacity);
    }
}

public class Main {
    public static void main(String[] args) {
      
        // Creating instances of vehicles
        Car car1 = new Car("Toyota", 50.0, 3, 4);
        Car car2 = new Car("Honda", 60.0, 4, 2);
        Truck truck1 = new Truck("Volvo", 100.0, 2, 5.0);
        Truck truck2 = new Truck("Ford", 110.0, 3, 6.0);
        Bike bike1 = new Bike("Yamaha", 40.0, 1, 150);
        Bike bike2 = new Bike("Kawasaki", 45.0, 2, 200);

        // Array of vehicles
        Vehicle[] fleetArray = {car1, truck1, bike1};
        System.out.println("Array Fleet:");
        for (Vehicle vehicle : fleetArray) {
            vehicle.displayDetails();
        }

        // ArrayList of vehicles
        ArrayList<Vehicle> fleetList = new ArrayList<>();
        fleetList.add(car2);
        fleetList.add(truck2);
        fleetList.add(bike2);

        System.out.println("\nArrayList Fleet:");
        for (Vehicle vehicle : fleetList) {
            vehicle.displayDetails();
        }

        // Removing a vehicle from the ArrayList
        System.out.println("\nVehicle Removed: " + fleetList.get(1).getClass().getSimpleName() + " - Brand: " + fleetList.get(1).brand);
        fleetList.remove(1);
  
        // Display updated ArrayList
        System.out.println("Updated ArrayList Fleet:");
        for (Vehicle vehicle : fleetList) {
            vehicle.displayDetails();
        }
    }
}