//Hamad Mohammed Aljenibi - 784-2007-8096410-0 - 201315094 - 12/CAI

// A. Create an optional string variable and initialize it
var optionalString: String? = "Hello Swift"

// B. Use an if statement to check if optionalString has a value
if let value = optionalString {
    print("The optional string has a value of \(value)")
} else {
    print("The optional string is nil")
}
