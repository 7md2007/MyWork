//Hamad Mohammed Aljenibi - 784-2007-8096410-0 - 201315094 - 12/CAI

// A. Create an optional string variable and initialize it to nil
var optionalValue: String? = nil

// B. Use optional binding (if let) to safely unwrap the value
if let value = optionalValue {
    print("The value is \(value)")
} else {
    print("The optional value is nil")
}
