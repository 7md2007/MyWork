/*
 * Name: Hamad Mohammed Aljenibi
 * School ID: 2013150794
 * EID: 784202089064100
 * Class: 12/CAI
 * Date:
 */

public class Factorial {
    public static void main(String[] args) {
        // Define the number for which we need to calculate factorial
        int num = 5;

        // Call the recursive factorial function and store the result
        long fact = factorial(num);

        // Print the output
        System.out.println("Factorial of " + num + " = " + fact);
    }

    /*
     * Recursive function to calculate the factorial of a number.
     * Factorial(n) is defined as:
     * n! = n × (n - 1) × (n - 2) × ... × 1
     * Base case: 0! = 1
     * Recursive case: n! = n × (n - 1)!
     */
    public static int factorial(int n) {
        // Base case: if n is 0, return 1
        if (n == 0) {
            return 1;
        } 
        // Recursive case: multiply n by factorial of (n - 1)
        else {
            return n * factorial(n - 1);
        }
    }
}
