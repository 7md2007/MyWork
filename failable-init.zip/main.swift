//Hamad Mohammed Aljenibi - 784-2007-8096410-0 - 201315094 - 12/CAI
class Person {
    var name: String
    var age: Int

    // PC8.5 - Failable initializer
    init?(name: String, age: Int) {
        if age < 0 {
            return nil  // Return nil if age is negative
        }
        self.name = name
        self.age = age
    }
}

// Creating an instance of Person
let person1 = Person(name: "Rashid", age: 18)

if let p1 = person1 {
    print("\(p1.name) is \(p1.age) years old")
} else {
    print("The age specified for the person is incorrect")
}
